import pygame

# Initialize Pygame
pygame.init()

# Set the dimensions of the game window
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update the game display
    pygame.display.update()

# Quit Pygame
pygame.quit()