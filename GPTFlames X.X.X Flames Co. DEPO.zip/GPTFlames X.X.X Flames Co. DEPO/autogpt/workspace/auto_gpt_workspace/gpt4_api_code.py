import openai

openai.api_key = "your openai api key"

user_prompt = "your prompt here"

openai.ChatCompletion.create (
    model="gpt-4",
    messages= [
        {"role": "user", "content": user_prompt}
    ]
)