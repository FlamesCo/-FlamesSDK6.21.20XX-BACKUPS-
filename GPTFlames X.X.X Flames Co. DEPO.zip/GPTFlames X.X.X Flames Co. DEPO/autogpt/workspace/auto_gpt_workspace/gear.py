class Gear(pygame.sprite.Sprite):
    def __init__(self, type):
        super().__init__()
        self.type = type
        self.image = pygame.Surface((30, 30))
        self.rect = self.image.get_rect()

    def use(self):
        if self.type == 'health':
            player.health += 10
        elif self.type == 'ammo':
            player.ammo += 10