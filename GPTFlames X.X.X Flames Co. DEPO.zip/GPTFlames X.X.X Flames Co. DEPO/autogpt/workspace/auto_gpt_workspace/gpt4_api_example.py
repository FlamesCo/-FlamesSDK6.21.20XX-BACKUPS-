def generate_response(user_input):
    response = openai.ChatCompletion.create (
        model="gpt-4" ,
        messages= [
            {"role": "system", "content": prompt},
            {"role": "user", "content": user_input},
        ]
    )
    message = response.choices [0 ].message.content
    return message
print ("\n\nPython script to connect with GPT-4.\nTo exit, just type exit or press Ctrl + C\n\n"