import docker

client = docker.from_env()

# List all containers
for container in client.containers.list():
  print(container.id)