import os

# Function to check if Docker is running
def check_docker():
    try:
        os.system('docker ps')
    except Exception as e:
        print('Docker is not running. Starting Docker...')
        os.system('systemctl start docker')

check_docker()