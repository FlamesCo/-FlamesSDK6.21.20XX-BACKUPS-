from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import gnupg

# Function for RSA encryption
def rsa_encryption(message):
    key = RSA.generate(2048)
    cipher = PKCS1_OAEP.new(key)
    encrypted_message = cipher.encrypt(message)
    return encrypted_message

# Function for PGP encryption
def pgp_encryption(message):
    gpg = gnupg.GPG()
    encrypted_message = gpg.encrypt(message, 'recipient')
    return encrypted_message